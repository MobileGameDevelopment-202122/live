

--
-- Complete the 'organizingContainers' function below.
--
-- The function is expected to return a STRING.
-- The function accepts 2D_INTEGER_ARRAY container as parameter.
--

local function organizingContainers(container)
    -- Write your code here

end


-- i.o code

local q = io.stdin:read("*n", "*l")

for qitr = 1, q do
    local n = io.stdin:read("*n", "*l")

    local container = {}

    for i = 1, n do
        container[i] = {}

        for token in string.gmatch(io.stdin:read("*l"):gsub("%s+$", ""), "[^%s]+") do
            table.insert(container[i], tonumber(token:match("(.-)%s*$")))
        end
    end

    local result = organizingContainers(container)

    print(result)
end


