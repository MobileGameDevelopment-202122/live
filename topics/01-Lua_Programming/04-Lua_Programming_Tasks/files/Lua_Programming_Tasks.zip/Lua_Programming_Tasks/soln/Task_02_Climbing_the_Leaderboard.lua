

--
-- Complete the 'climbingLeaderboard' function below.
--
-- The function is expected to return an INTEGER_ARRAY.
-- The function accepts following parameters:
--  1. INTEGER_ARRAY scores
--  2. INTEGER_ARRAY player
--

local function climbingLeaderboard(scores, player)
    -- Write your code here

    local tmp = {}
	for _,r in ipairs(ranked) do tmp[r] = r end
	local leaderboard = {}
	for _,v in pairs(tmp) do
		table.insert(leaderboard, v)
	end
	table.sort(leaderboard, function (a,b) return a>b end ) 

	local l = #leaderboard + 1

	local result = {}
	for _,p in ipairs(player) do
	    while (l > 1) and (p >= leaderboard[l-1]) do
	        l = l - 1
		end
	    table.insert(result, l)
	end
	return result
end

-- i/o code

local scorecount = io.stdin:read("*n", "*l")

local scores = {}

for token in string.gmatch(io.stdin:read("*l"):gsub("%s+$", ""), "[^%s]+") do
    table.insert(scores, tonumber(token))
end

local playercount = io.stdin:read("*n", "*l")

local player = {}

for token in string.gmatch(io.stdin:read("*l"):gsub("%s+$", ""), "[^%s]+") do
    table.insert(player, tonumber(token))
end


for k,v in pairs(scores) do
	print("ONE", k, v)
end
for k,v in pairs(player) do
	print("HERE", k, v)
end

local result = climbingLeaderboard(scores, player)

print(table.concat(result, "\n"))

