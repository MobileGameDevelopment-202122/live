#!/usr/bin/env lua


-- Complete the designerPdfViewer function below.
local function designerPdfViewer(h, word)
	local max_height = 0
	for k = 1, #word do
		local index = string.byte(word,k) - string.byte('a') + 1
		local height = h[index]
		if height>max_height then
			max_height=height
		end
	end
	return max_height * #word
end


-- i/o code

local h = {}

for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
    table.insert(h, tonumber(token))
end

local word = io.stdin:read("*l")

local result = designerPdfViewer(h, word)

print(result)

