

-- Complete the formingMagicSquare function below.
local function formingMagicSquare(s)

	local squares = {
        {{2,7,6}, {9,5,1}, {4,3,8}},
        {{2,9,4}, {7,5,3}, {6,1,8}},
        {{4,3,8}, {9,5,1}, {2,7,6}},
        {{4,9,2}, {3,5,7}, {8,1,6}},
        {{6,7,2}, {1,5,9}, {8,3,4}},
        {{6,1,8}, {7,5,3}, {2,9,4}},
        {{8,3,4}, {1,5,9}, {6,7,2}},
        {{8,1,6}, {3,5,7}, {4,9,2}}
	}

	local min_cost = math.maxinteger

	for _, square in pairs(squares) do
		local cost = 0

		for r = 1,3 do
			for c = 1,3 do
				cost = cost + math.abs(s[r][c]-square[r][c] )
			end
		end
		if cost<min_cost then min_cost=cost end
	end

	return min_cost

end



-- i/o code

local s = {}

for i = 1, 3 do
    s[i] = {}

    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(s[i], tonumber(token:match("(.-)%s*$")))
    end
end

local result = formingMagicSquare(s)

print(result)

