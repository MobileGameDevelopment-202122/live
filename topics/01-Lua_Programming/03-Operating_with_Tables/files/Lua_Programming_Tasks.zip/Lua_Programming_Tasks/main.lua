#!/usr/bin/env lua

-- Basic test script to check lua programs by comparing observed vs expected output
-- version 1: 
-- version 2: added identifier to support OSX/linux or win path separator
---version 3: replaced missing output lines by black (stoped output error in line 116 so some)

debug = false
path_sep = package.config:sub(1,1)

require "lfs"

function isDir(name)
  
  assert (type(name)=="string", "Need to pass string to isDir function")
  
  local cd = lfs.currentdir()
  local is = lfs.chdir(name) and true or false
  lfs.chdir(cd)
  return is
end

function split(s, sep)
  -- Generic split function, using character sep.

  local fields = {}
    
  local sep = sep or " "
  local pattern = string.format("([^%s]+)", sep)
  string.gsub(s, pattern, function(c) fields[#fields + 1] = c end)
    
  return fields
end


function get_problems()
  -- Compile list of problems to test.
  -- ASSUME files in src_orig will not change. This sould be true as only copy out files when needed

  local problems = {}
  for file in lfs.dir('src_orig') do
    if file ~= "." and file ~= ".." then
      local num = string.sub(file, 6, 7)
      local basename = string.sub(file, 9, -5)
      problems[num] = basename
    end
  end
  
  -- generate sort order
  local ordered_problems_keys = {}
  for k in pairs(problems) do
    table.insert(ordered_problems_keys, k)
  end
  table.sort(ordered_problems_keys)

  return ordered_problems_keys, problems
end



local ordered_problems_keys, problems = get_problems()


function get_problem_tests(n, test_set)
  -- Compile list of tests in given test_set for given problem
  
  local tests = {}
  
  if not (isDir(test_set) and isDir(test_set .. path_sep .."Task_"..n)) then
      if debug then io.write(string.format("No tests found for %s", test_set)) end
      return tests
  end
  
  test_set = test_set or "tests"
  for file in lfs.dir(test_set .. path_sep .."Task_"..n) do
    if file ~= "." and file ~= ".." and string.find(file, ".in") ~= nil then
      tests[#tests+1] = string.gsub(file, ".in", "")
    end
  end
  table.sort(tests)
  return tests
end

function read_file(filename)
  local data = {}
  local handle = io.open(filename, "r")
  for line in handle:lines() do
    table.insert(data, line)
  end
  return data
end


function run_test_on_script(n, script, test_set, test_n) 
  --
  test = "Task_" .. n .. path_sep .. test_n
  io.write(string.format("\n\nTest (%s) : %s\n", test_set, test))
  io.write(string.rep("-", 10 + #test_set + #test) .. "\n\n")
    
  -- run script again test
  script_file = "soln/Task_" .. n .. "_" .. script ..".lua"
  test_file_in = test_set .. path_sep .. test .. ".in"
  test_file_obs = test_set .. path_sep .. test .. ".obs"
  io.popen("lua " .. script_file .." < " .. test_file_in  .. " > " .. test_file_obs)
    
  -- compare observed(obs) vs expected (out)
  obs_data = read_file(test_set .. path_sep .. test .. ".obs")
  exp_data = read_file(test_set .. path_sep .. test .. ".out")
    
  io.write(string.format("%3s | %s | %-40s | %-40s\n", "N", "R", "Expected", "Observed"))
  io.write(string.rep("-",90), "\n")
  count = 0
  
  for k = 1, math.max(#exp_data,#obs_data) do
    obs_line = obs_data[k] or ""
    exp_line = exp_data[k] or ""

    r = (exp_line==obs_line and ".") or "X"
    count = (r=="X" and 1) or 0
    io.write(string.format("%3s | %s | %-40s | %-40s\n", k, r, exp_line, obs_line))
  end
  
  if count>0 then
    print(string.format("\nNumber of mismatches: %s", count))
  end
    
  return (count>0 and 1) or 0
end


function run_test_set_on_script(n, script, test_set)  
  
  local tests = get_problem_tests(n, test_set)
  fail_test_count = 0
  for k, test_n in pairs(tests) do
    fail_test_count = fail_test_count + run_test_on_script(n, script, test_set, test_n)
  end
  io.write(string.format("\nNumber of %s failed: %d\n", test_set, fail_test_count))
  
end

function test_script(n) 
  script = problems[n]
  io.write(string.format("\n\nProblem: (%s) %s\n", n, script))
  io.write(string.rep("=", 14 + #script))
  
  run_test_set_on_script(n, script, "tests")
  run_test_set_on_script(n, script, "extra_tests")
end


-- parse command line arguments and run tests
local path = split(lfs.currentdir(), path_sep)
assert (path[#path]=="Lua_Programming_Tasks", "Need to set project directory to be Lua_Programming_Tasks")

if not arg[1] then
  io.write("No command line parameters specified.\n"
    .. "Usage\n"
    .. "  main ALL|NUM\n"
    .. "  where NUM is All or a number of a particular problem\n")
  io.write("List of problems:\n")
  for i = 1, #ordered_problems_keys do
    local k, v = ordered_problems_keys[i], problems[ordered_problems_keys[i]]
    io.write(string.format("\t%s\t%s\n", k,v))
  end
  
  problem = "04"
  io.write(string.format("Testing (default) problems: %s\n", problem))
  test_script(problem)

elseif string.upper(arg[1]) == "ALL" then
  for i = 1, #ordered_problems_keys do
    test_script(ordered_problems_keys[i])
  end
  
else
  problem = string.format("%02d", arg[1])
  test_script(problem)
end





