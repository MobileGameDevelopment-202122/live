

-- Complete the queensAttack function below.
function queensAttack(n, k, r_q, c_q, obstacles)


end


local nk = {}
for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
    table.insert(nk, token)
end

local n = tonumber(nk[1]:match("^%s*(.-)%s*$"))

local k = tonumber(nk[2]:match("^%s*(.-)%s*$"))

local r_qC_q = {}
for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
    table.insert(r_qC_q, token)
end

local r_q = tonumber(r_qC_q[1]:match("^%s*(.-)%s*$"))

local c_q = tonumber(r_qC_q[2]:match("^%s*(.-)%s*$"))

local obstacles = {}

for i = 1, k do
    obstacles[i] = {}

    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(obstacles[i], tonumber(token:match("(.-)%s*$")))
    end
end

local result = queensAttack(n, k, r_q, c_q, obstacles)

print(result)

