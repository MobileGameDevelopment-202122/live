#!/usr/bin/env lua

-- Basic test script to check lua programs by comparing observed vs expected output
-- version 1: 
-- version 2: added identifier to support OSX/linux or win path separator
-- version 3: replaced missing output lines by black (stopped output error in line 116)
-- version 4: wrapped call to running script in an assert and closed output - avoids needs for second run.
-- version 5: added better error messages 

-- debug = true
path_sep = package.config:sub(1,1)

require "lfs"


function isDir(name)
  -- Tests if name is a subfolder (returns boolean).
  
  assert (type(name)=="string", "Need to pass string to isDir function")
  
  -- test existance by attempting to change folder into subfolder (then change back)
  local cwd = lfs.currentdir()
  local result = lfs.chdir(name) and true or false
  lfs.chdir(cwd)

  return result
end
assert (isDir("doc")==true, "testing isDir - subfolder doc should exist. Check setup.")
assert (isDir("random_name")==false, "testing isDir - should have returned false.")


function split(s, sep)
  -- Generic split function, using character sep (default space), returns table.

  local sep = sep or " "
  
  local fields = {}
  local pattern = string.format("([^%s]+)", sep)
  string.gsub(s, pattern, function(c) fields[#fields + 1] = c end)
    
  return fields
end
assert(#split("")==0)
assert(#split("a")==1)
assert(#split("a b")==2)
assert(#split("a b", ",")==1)
assert(split("aaa bbb cc")[2]=="bbb")


function get_problems(debug)
  -- Compile list of problems to test.

  -- identify problems by files in soln sub-folder and having patterm ##_Name.lua
  local problems = {}
  for file in lfs.dir('soln') do
    if file ~= "." and file ~= ".." then
	  assert(string.sub(file, 7, 7)=="_" and string.sub(file, -4, -1)==".lua", "Expected filename with pattern '##_Name.lua")
      local num = string.sub(file, 5, 6)
      local basename = string.sub(file, 8, -5)
      problems[num] = basename
	  if debug then print("get_problems", "problem", num, basename) end
    end
  end
  
  -- generate sort order (by problem num)
  local ordered_problems_keys = {}
  for k in pairs(problems) do
    table.insert(ordered_problems_keys, k)
  end
  table.sort(ordered_problems_keys)

  return ordered_problems_keys, problems
end


if not isDir('soln') then
  io.write('No soln subfolder found. No code to test.')
  return
end
local ordered_problems_keys, problems = get_problems()



function get_problem_tests(n, test_set, debug)
  -- Compile list of tests in given test_set for given problem, n.
  
  local tests = {}
  
  if not (isDir(test_set) and isDir(test_set .. path_sep .."Day_"..n)) then
      if debug then io.write(string.format("No tests found for %s", test_set)) end
      return tests
  end
  
  test_set = test_set or "tests"
  for file in lfs.dir(test_set .. path_sep .."Day_"..n) do
    if file ~= "." and file ~= ".." and string.find(file, ".in") ~= nil then
      tests[#tests+1] = string.gsub(file, ".in", "")
    end
  end
  table.sort(tests)
  return tests
end

function read_file(filename)
  local data = {}
  local handle = io.open(filename, "r")
  for line in handle:lines() do
    table.insert(data, line)
  end
  return data
end


function run_test_on_script(n, script, test_set, test_n, debug) 
  --
  test = "Day_" .. n .. path_sep .. test_n
  io.write(string.format("\n\nTest (%s) : %s\n", test_set, test))
  io.write(string.rep("-", 10 + #test_set + #test) .. "\n\n")
  
  -- run script again test
  script_file = "soln/Day_" .. n .. "_" .. script ..".lua"
  test_file_in = test_set .. path_sep .. test .. ".in"
  test_file_obs = test_set .. path_sep .. test .. ".obs"
  
  f = assert(io.popen("lua " .. script_file .." < " .. test_file_in  .. " > " .. test_file_obs), 
    "Running code script " .. script .. "failed")
  f:close()
  
  -- compare observed(obs) vs expected (out)
  obs_data = read_file(test_set .. path_sep .. test .. ".obs")
  exp_data = read_file(test_set .. path_sep .. test .. ".out")
    
  io.write(string.format("%3s | %s | %-40s | %-40s\n", "N", "R", "Expected", "Observed"))
  io.write(string.rep("-",90), "\n")
  count = 0
  
  -- iterate over all rows in output files (shorter file missing rows replaced by "")
  for k = 1, math.max(#exp_data,#obs_data) do
    obs_line = obs_data[k] or ""
    exp_line = exp_data[k] or ""

    r = (exp_line==obs_line and ".") or "X"
    count = count + ((r=="X" and 1) or 0)
    io.write(string.format("%3s | %s | %-40s | %-40s\n", k, r, exp_line, obs_line))
  end
  
  if count>0 then
    print(string.format("\nNumber of mismatches: %s", count))
  end
    
  return (count>0 and 1) or 0
end


function run_test_set_on_script(n, script, test_set)  
  
  local tests = get_problem_tests(n, test_set)
  fail_test_count = 0
  for k, test_n in pairs(tests) do
    fail_test_count = fail_test_count + run_test_on_script(n, script, test_set, test_n, true)
  end
  io.write(string.format("\nNumber of %s failed: %d\n", test_set, fail_test_count))
  
end


function test_script(n) 
	-- test problem n using testset in tests and in extra_tests
	
	-- print header
  script = problems[n]
  io.write(string.format("\n\nProblem: (%s) %s\n", n, script))
  io.write(string.rep("=", 14 + #script))
  
  run_test_set_on_script(n, script, "tests")
  run_test_set_on_script(n, script, "extra_tests")
end


-- parse command line arguments and run tests
local path = split(lfs.currentdir(), path_sep)
-- assert (path[#path]=="30_Days_of_Code_Lua", "Need to set project directory to be 30_Days_of_Code")

if not arg[1] then
  io.write("No command line parameters specified.\n"
    .. "Usage\n"
    .. "  main ALL|NUM\n"
    .. "  where NUM is zero-padded number of a particular problem\n")
  io.write("List of problems:\n")
  for i = 1, #ordered_problems_keys do
    local k, v = ordered_problems_keys[i], problems[ordered_problems_keys[i]]
    io.write(string.format("\t%s\t%s\n", k,v))
  end
  
  problem = "04"
  io.write(string.format("Testing (default) problems: %s\n", problem))
  test_script(problem)

elseif string.upper(arg[1]) == "ALL" then
  for i = 1, #ordered_problems_keys do
    test_script(ordered_problems_keys[i])
  end
  
else
  problem = string.format("%02d", arg[1])
  test_script(problem)
end





