#!/usr/bin/env lua

local n = io.stdin:read("*n", "*l")

local arr = {}

for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
    table.insert(arr, tonumber(token))
end
