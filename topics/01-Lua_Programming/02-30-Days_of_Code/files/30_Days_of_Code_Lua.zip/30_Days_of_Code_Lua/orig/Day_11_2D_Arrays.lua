#!/usr/bin/env lua

local arr = {}

for i = 1, 6 do
    arr[i] = {}

    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(arr[i], tonumber(token:match("(.-)%s*$")))
    end
end
