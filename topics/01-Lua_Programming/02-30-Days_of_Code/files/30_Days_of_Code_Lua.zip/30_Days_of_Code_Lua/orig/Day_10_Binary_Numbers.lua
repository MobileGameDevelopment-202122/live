#!/usr/bin/env lua

local n = io.stdin:read("*n", "*l")