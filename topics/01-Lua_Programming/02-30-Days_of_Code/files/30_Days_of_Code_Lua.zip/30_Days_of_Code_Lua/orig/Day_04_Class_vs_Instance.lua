#!/usr/bin/env lua

local Person = { };
Person.__index = Person
 
function Person.new (initialAge)
   local self = setmetatable({ },Person);
   -- Add some more code to run some checks on initialAge       
   return self;
end
function Person:amIOld()
    -- Do some computations in here and print out the correct statement to the console  
end
function Person:yearPasses ()
   -- Increment the age
end

local read = io.read;
local T = read'*n';
for i = 1,T do
   local age = read'*n';
   local p = Person.new(age);
   p:amIOld();
   for j = 1,3 do
      p:yearPasses();
   end
   p:amIOld();
   print"";
end