#!/usr/bin/env lua

-- Complete the solve function below.
function solve(meal_cost, tip_percent, tax_percent)


end

local meal_cost = io.stdin:read("*n", "*l")

local tip_percent = io.stdin:read("*n", "*l")

local tax_percent = io.stdin:read("*n", "*l")

solve(meal_cost, tip_percent, tax_percent)
