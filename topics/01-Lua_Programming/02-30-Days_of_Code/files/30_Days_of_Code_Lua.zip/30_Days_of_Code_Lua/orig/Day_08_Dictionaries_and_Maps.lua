#!/usr/bin/env lua

-- Enter your code here. Read input from STDIN. Print output to STDOUT