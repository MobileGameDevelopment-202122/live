#!/usr/bin/env lua

-- Complete the factorial function below.
function factorial(n)


end

local n = io.stdin:read("*n", "*l")
local result = factorial(n)
print(result)
