#!/usr/bin/env lua

local N = io.stdin:read("*n", "*l")

for Nitr = 1, N do
    local firstNameEmailID = {}
    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(firstNameEmailID, token)
    end

    local firstName = firstNameEmailID[1]

    local emailID = firstNameEmailID[2]
end