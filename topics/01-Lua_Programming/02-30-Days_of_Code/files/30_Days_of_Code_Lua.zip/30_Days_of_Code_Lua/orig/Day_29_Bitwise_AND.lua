#!/usr/bin/env lua

local t = io.stdin:read("*n", "*l")

for titr = 1, t do
    local nk = {}
    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(nk, token)
    end

    local n = tonumber(nk[1]:match("^%s*(.-)%s*$"))

    local k = tonumber(nk[2]:match("^%s*(.-)%s*$"))

end
