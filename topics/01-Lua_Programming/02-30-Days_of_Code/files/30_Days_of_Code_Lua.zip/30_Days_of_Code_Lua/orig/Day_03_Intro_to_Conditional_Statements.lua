#!/usr/bin/env lua

local N = io.stdin:read("*n", "*l")
