#!/usr/bin/env lua

n = io.read("*number", "*l")
a = {}
a_temp = io.read()
a_i = 1;
for token in string.gmatch(a_temp, "[^%s]+") do
	a[a_i] = token
	a_i = a_i + 1
end
-- Write Your Code Here